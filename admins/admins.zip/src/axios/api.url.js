export default {
  DOMAIN: 'http://localhost',
  // baseURL: 'http://www.shehua56.com',
  baseURL: '',
  // baseURL: 'https://csi-securities.vip',

  util: {
    image: '/util/image.html' // 图片上传
  }
}
